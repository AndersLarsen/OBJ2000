




import javahjelp.*;

public class TestContinue {


static public void main(String[] s) {
	System.out.println("Beregn gjennomsnittet av hele tall. Tast 0 for � beregne");
    int antall	= 0;
    int sum		= 0;
	while (true) {  // continue hopper hit
		int n = Konsoll.readInt("Tast et positivt heltall");
		if (n<0) {
			System.out.println("Negative tall regnes ikke med");
			continue;
		}
		if (n==0) break;
		sum += n;
		antall++;
	}
	// break hopper hit
	System.out.println("Avrundet gjennomsnitt av dine "+antall+" postitive tall er "+Math.round(sum/antall));
  }

}