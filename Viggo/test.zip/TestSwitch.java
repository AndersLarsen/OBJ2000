

/*



*/


import javahjelp.*;


public class TestSwitch {

static private int meny () {

 System.out.println("===============");
 System.out.println("Velg fra menyen");
 System.out.println("---------------");
 System.out.println("Tast 1 for � velge 1");
 System.out.println("Tast 2 for � velge 2");
 System.out.println("Tast 3 for � velge 3");

 int m1 =  Konsoll.readInt("\r\nTast et tall, eller tast 0 for � ikke velge noe");
 return m1;
}



static private void utf�rValget() {

  System.out.println("---------------------------------");
  System.out.println("Tester MED break mellom hver case");
  System.out.println("---------------------------------");

  int valg = meny();

  switch(valg) {
  case 0 : break;
  case 1 : System.out.println("Du valgte 1");
    	   break;
  case 2 : System.out.println("Du valgte 2");
    	   break;
  case 3 : System.out.println("Du valgte 3");
    	   break;
  default : System.out.println("Ugyldig valg. Ingenting er gjort!");
  }
  System.out.println("Forgreningen med switch er ferdig\r\n");
 }


static private void utf�rValgetUten_break() {

  System.out.println("---------------------------------");
  System.out.println("Tester UTEN break mellom hver case");
  System.out.println("---------------------------------");

  int valg = meny();

  switch(valg) {
  case 0 : break;
  case 1 : System.out.println("Du valgte 1");
  case 2 : System.out.println("Du valgte 1 eller 2");
  case 3 : System.out.println("Du valgte 1, 2 eller 3");
  default : System.out.println("1, 2, 3 eller ugyldig!");
  }
  System.out.println("Forgreningen med switch er ferdig\r\n");
 }






public static void main(String[] s) {

	utf�rValget();
	utf�rValgetUten_break();

  }


}