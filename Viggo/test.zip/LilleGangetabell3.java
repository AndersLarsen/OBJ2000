
/*

Dette l�sningsforslaget skriver ut den lille
gangetabellen pent formattert i rader og kolonner.

Programmet bruker to for-l�kker.

Produktet testes f�r utskrift for � fortelle hvor mange
mellomrom som skal skrives ut f�r selve tallet.

Siffer + mellomrom m� bruke like mange plasser hver gang,
for at kolonnene skal bli helt rette.

Produktet lagres i variablen "p" for � brukes i metoden formatterTall

*/



public class LilleGangetabell3 {

static int p;


static String formatterTall() {
	String s = ""+p;  			// Lar tallverdien bli en streng
	while (true) {				// Evig l�kke til return blir brukt
	if (s.length()==4) return s;// Returnerer strengen hvis den er lang nok
	s = " "+s;					// Skyver tallet mot h�yre med ett mellomrom
	}
}



/* Eksempel med for-l�kke
static String formatterTall() {
  String s = ""+p;
  for (int i=s.length();i<4;i++) s = " "+s;
  return s;
}
*/


static public void main(String[] s) {
	for (int i=1; i<11; i++) {
	   System.out.println();               		// ett linjeskift f�r hver rad
	   for (int j=1; j<11; j++) {
		   p = i * j;
		   System.out.print(formatterTall());
	   }
	  }
	  System.out.println("");
	  System.out.println("");
	}

}

