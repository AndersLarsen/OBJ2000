

/*
  Dette eksemplet tar utgangspunkt i l�sningsforslaget for klassen SettSammen.java
  Bruk av break forenkler i dette tilfellet algoritmen i main.
*/

import javahjelp.*;

public class TestFlytkontroll {

static String delEn() {
  return Konsoll.readLine("Tast inn f�rste del av et sammensatt ord");
}


static String delTo() {
  return Konsoll.readLine("Tast inn andre del av et sammensatt ord");
}



public static void main(String[] args) {
  String s1 = "";
  String s2 = "";
  do {
	  System.out.println("Tast inn to orddeler\r");
	  s1 = delEn();
	  if (s1.equals("")) break;
	  s2 = delTo();
      if (s2.equals("")) break;
	  System.out.println("Ordet blir "+s1+s2);
	  }
  while (true);
 } // break hopper hit

}






