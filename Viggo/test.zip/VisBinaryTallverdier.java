




public class VisBinaryTallverdier {


static public void main(String[] s) {

	int i;			// tallverdien
	int j;			// bitens posisjon regnet fra h�yre mot venstre

	System.out.println("============================================================");
	System.out.println("Dette programmet viser alle tallverdiene i et 16 biters tall");
	System.out.println("------------------------------------------------------------");

	for (i=1,j=0;j<16; i+=i,j++)
	    System.out.println("bit "+j+" har tallverdien "+i);

	System.out.println();

 }


}
